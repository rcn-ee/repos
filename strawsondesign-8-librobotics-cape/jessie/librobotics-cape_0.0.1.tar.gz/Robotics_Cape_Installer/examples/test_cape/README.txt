test_cape.c
James Strawson 2016

This is the routine used by the factory for testing capes as they come off the
assembly line. It requires a factory testing jig and is not meant for the 
end-user.

