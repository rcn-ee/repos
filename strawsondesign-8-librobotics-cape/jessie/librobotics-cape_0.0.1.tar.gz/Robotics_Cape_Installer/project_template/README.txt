This is meant to be a starting point for your own project. To begin your
own librobotics-cape project follow these steps


1. 	Copy this project_template folder and its contents to your own working
	directory such as /root/

2. 	Rename the folder and .c file to your own project name

3.	Rename the TARGET variable in Makefile to match your project name.

4.	Update this README.txt to contain a short description of your project.
